export interface Movie {
  id: string;
  title: string;
  poster: string;
  backdrop: string;
  year: number;
  rating: string;
  duration: string;
  match: number;
  genre: string[];
  description: string;
  type: 'movie' | 'series';
}

export const featuredMovie: Movie = {
  id: '1',
  title: 'Hoppers',
  poster: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400&h=600&fit=crop',
  backdrop: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1200&h=800&fit=crop',
  year: 2024,
  rating: 'PG-13',
  duration: '2h 18m',
  match: 97,
  genre: ['Action', 'Sci-Fi', 'Thriller'],
  description: 'In a world where time bends and reality fractures, a group of elite agents must navigate through parallel dimensions to prevent catastrophic collapse.',
  type: 'movie'
};

export const trendingMovies: Movie[] = [
  {
    id: '2',
    title: 'Midnight Protocol',
    poster: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=1200&h=800&fit=crop',
    year: 2024,
    rating: 'R',
    duration: '1h 56m',
    match: 94,
    genre: ['Thriller', 'Mystery'],
    description: 'A retired spy is pulled back into action when a ghost from her past resurfaces.',
    type: 'movie'
  },
  {
    id: '3',
    title: 'Neon Dreams',
    poster: 'https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=1200&h=800&fit=crop',
    year: 2023,
    rating: 'PG-13',
    duration: '2h 4m',
    match: 89,
    genre: ['Sci-Fi', 'Romance'],
    description: 'In 2087 Tokyo, an AI gains consciousness and falls in love with its creator.',
    type: 'movie'
  },
  {
    id: '4',
    title: 'The Last Summit',
    poster: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=1200&h=800&fit=crop',
    year: 2024,
    rating: 'PG',
    duration: '1h 48m',
    match: 91,
    genre: ['Adventure', 'Drama'],
    description: 'A mountaineer attempts the impossible: climbing K2 in winter alone.',
    type: 'movie'
  },
  {
    id: '5',
    title: 'Crimson Tide',
    poster: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1200&h=800&fit=crop',
    year: 2023,
    rating: 'R',
    duration: '2h 12m',
    match: 86,
    genre: ['Horror', 'Thriller'],
    description: 'A coastal town faces an ancient terror rising from the depths.',
    type: 'movie'
  }
];

export const top10Movies: Movie[] = [
  {
    id: '6',
    title: 'Shadow Empire',
    poster: 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=1200&h=800&fit=crop',
    year: 2024,
    rating: 'R',
    duration: '2h 34m',
    match: 98,
    genre: ['Action', 'Drama'],
    description: 'The rise and fall of a criminal dynasty spanning three generations.',
    type: 'series'
  },
  {
    id: '7',
    title: 'Quantum Break',
    poster: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=1200&h=800&fit=crop',
    year: 2024,
    rating: 'PG-13',
    duration: '1h 52m',
    match: 95,
    genre: ['Sci-Fi', 'Action'],
    description: 'Scientists accidentally open a rift in spacetime.',
    type: 'movie'
  },
  {
    id: '8',
    title: 'Desert Storm',
    poster: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=1200&h=800&fit=crop',
    year: 2023,
    rating: 'R',
    duration: '2h 8m',
    match: 92,
    genre: ['War', 'Drama'],
    description: 'A gripping tale of survival in the harshest conditions.',
    type: 'movie'
  },
  {
    id: '9',
    title: 'Ocean\'s Edge',
    poster: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200&h=800&fit=crop',
    year: 2024,
    rating: 'PG-13',
    duration: '1h 44m',
    match: 88,
    genre: ['Adventure', 'Family'],
    description: 'A marine biologist discovers an underwater civilization.',
    type: 'movie'
  },
  {
    id: '10',
    title: 'Urban Legends',
    poster: 'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=1200&h=800&fit=crop',
    year: 2024,
    rating: 'R',
    duration: '2h 1m',
    match: 85,
    genre: ['Horror', 'Mystery'],
    description: 'City myths come to life in this anthology series.',
    type: 'series'
  },
  {
    id: '11',
    title: 'The Heist',
    poster: 'https://images.unsplash.com/photo-1501167786227-4cba60f6d58f?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1501167786227-4cba60f6d58f?w=1200&h=800&fit=crop',
    year: 2023,
    rating: 'PG-13',
    duration: '2h 15m',
    match: 93,
    genre: ['Crime', 'Thriller'],
    description: 'The perfect crime planned over a decade.',
    type: 'movie'
  },
  {
    id: '12',
    title: 'Northern Lights',
    poster: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=1200&h=800&fit=crop',
    year: 2024,
    rating: 'PG',
    duration: '1h 38m',
    match: 90,
    genre: ['Fantasy', 'Adventure'],
    description: 'A magical journey through the Arctic wilderness.',
    type: 'movie'
  },
  {
    id: '13',
    title: 'Code Red',
    poster: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=1200&h=800&fit=crop',
    year: 2024,
    rating: 'R',
    duration: '1h 58m',
    match: 87,
    genre: ['Thriller', 'Tech'],
    description: 'Hackers race against time to prevent global chaos.',
    type: 'movie'
  },
  {
    id: '14',
    title: 'Wild Hearts',
    poster: 'https://images.unsplash.com/photo-1504006833117-8886a355efbf?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1504006833117-8886a355efbf?w=1200&h=800&fit=crop',
    year: 2023,
    rating: 'PG-13',
    duration: '2h 6m',
    match: 84,
    genre: ['Romance', 'Drama'],
    description: 'Two souls find love in unexpected places.',
    type: 'movie'
  },
  {
    id: '15',
    title: 'Eternal Night',
    poster: 'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=1200&h=800&fit=crop',
    year: 2024,
    rating: 'R',
    duration: '2h 22m',
    match: 96,
    genre: ['Sci-Fi', 'Horror'],
    description: 'When the sun dies, humanity faces its darkest hour.',
    type: 'movie'
  }
];

export const tvShows: Movie[] = [
  {
    id: '16',
    title: 'Dynasty',
    poster: 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=1200&h=800&fit=crop',
    year: 2024,
    rating: 'TV-MA',
    duration: '5 Seasons',
    match: 94,
    genre: ['Drama', 'Crime'],
    description: 'Power, betrayal, and family secrets in the world of the ultra-wealthy.',
    type: 'series'
  },
  {
    id: '17',
    title: 'The Station',
    poster: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=1200&h=800&fit=crop',
    year: 2023,
    rating: 'TV-14',
    duration: '3 Seasons',
    match: 91,
    genre: ['Sci-Fi', 'Drama'],
    description: 'Life aboard humanity\'s first interstellar space station.',
    type: 'series'
  },
  {
    id: '18',
    title: 'Detectives',
    poster: 'https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=1200&h=800&fit=crop',
    year: 2024,
    rating: 'TV-MA',
    duration: '2 Seasons',
    match: 89,
    genre: ['Crime', 'Mystery'],
    description: 'Unconventional detectives solve the city\'s strangest cases.',
    type: 'series'
  },
  {
    id: '19',
    title: 'Kingdom',
    poster: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&h=800&fit=crop',
    year: 2023,
    rating: 'TV-MA',
    duration: '4 Seasons',
    match: 97,
    genre: ['Fantasy', 'Action'],
    description: 'Medieval kingdoms clash in an epic battle for the throne.',
    type: 'series'
  },
  {
    id: '20',
    title: 'Mind Games',
    poster: 'https://images.unsplash.com/photo-1559757175-5700dde675bc?w=400&h=600&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1559757175-5700dde675bc?w=1200&h=800&fit=crop',
    year: 2024,
    rating: 'TV-14',
    duration: '1 Season',
    match: 86,
    genre: ['Thriller', 'Drama'],
    description: 'A psychologist discovers her patients share a dark secret.',
    type: 'series'
  }
];

export const genres = [
  'All',
  'Action',
  'Comedy',
  'Drama',
  'Horror',
  'Sci-Fi',
  'Romance',
  'Thriller',
  'Fantasy',
  'Documentary'
];

export const allContent = [...trendingMovies, ...top10Movies, ...tvShows, featuredMovie];
