import { useState } from 'react';
import { useNavigate } from 'react-router';
import Header from '@/react-app/components/Header';
import GenreChips from '@/react-app/components/GenreChips';
import MovieCard from '@/react-app/components/MovieCard';
import BottomNav from '@/react-app/components/BottomNav';
import { tvShows, top10Movies, genres, Movie } from '@/data/movies';

const allShows = [...tvShows, ...top10Movies.filter(m => m.type === 'series')];

export default function TVShowsPage() {
  const navigate = useNavigate();
  const [selectedGenre, setSelectedGenre] = useState('All');

  const filteredShows = selectedGenre === 'All' 
    ? allShows 
    : allShows.filter(m => m.genre.includes(selectedGenre));

  const handleShowClick = (movie: Movie) => {
    navigate(`/watch/${movie.id}`);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] pt-16 pb-20">
      <Header onProfileClick={() => navigate('/login')} />

      <div className="px-4 py-4">
        <h1 className="text-2xl font-bold text-white mb-4">TV Shows</h1>
        
        <GenreChips 
          genres={genres} 
          selected={selectedGenre} 
          onSelect={setSelectedGenre} 
        />

        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3 mt-6">
          {filteredShows.map((show) => (
            <div key={show.id} className="aspect-[2/3]">
              <MovieCard 
                movie={show} 
                onClick={handleShowClick}
                size="small"
              />
            </div>
          ))}
        </div>

        {filteredShows.length === 0 && (
          <div className="text-center py-20">
            <p className="text-white/50">No shows found in this genre</p>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
