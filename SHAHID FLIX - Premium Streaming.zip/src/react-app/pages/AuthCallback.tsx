import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router';

export default function AuthCallbackPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const code = searchParams.get('code');
    
    if (!code) {
      setError('No authorization code provided');
      return;
    }

    const exchangeCode = async () => {
      try {
        const response = await fetch('/api/sessions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ code }),
        });

        if (!response.ok) {
          throw new Error('Failed to exchange code for session');
        }

        // Successfully logged in, redirect to home
        navigate('/', { replace: true });
      } catch (err) {
        console.error('Auth callback error:', err);
        setError('Failed to complete login. Please try again.');
      }
    };

    exchangeCode();
  }, [searchParams, navigate]);

  return (
    <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center">
      <div className="text-center">
        {error ? (
          <>
            <div className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">⚠️</span>
            </div>
            <h2 className="text-xl font-bold text-white mb-2">Login Failed</h2>
            <p className="text-white/60 mb-6">{error}</p>
            <button
              onClick={() => navigate('/login')}
              className="px-6 py-3 bg-[#E50914] text-white font-semibold rounded-lg hover:bg-[#B20710] transition-colors"
            >
              Try Again
            </button>
          </>
        ) : (
          <>
            <div className="w-16 h-16 rounded-full bg-[#E50914]/20 flex items-center justify-center mx-auto mb-4 animate-pulse">
              <div className="w-8 h-8 border-3 border-[#E50914] border-t-transparent rounded-full animate-spin" />
            </div>
            <h2 className="text-xl font-bold text-white mb-2">Signing you in...</h2>
            <p className="text-white/60">Please wait while we complete your login</p>
          </>
        )}
      </div>
    </div>
  );
}
