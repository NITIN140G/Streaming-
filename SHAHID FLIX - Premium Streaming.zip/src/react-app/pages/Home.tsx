import { useState } from 'react';
import { useNavigate } from 'react-router';
import Header from '@/react-app/components/Header';
import HeroSection from '@/react-app/components/HeroSection';
import ContentRow from '@/react-app/components/ContentRow';
import GenreChips from '@/react-app/components/GenreChips';
import BottomNav from '@/react-app/components/BottomNav';
import { 
  featuredMovie, 
  trendingMovies, 
  top10Movies, 
  tvShows,
  genres,
  Movie
} from '@/data/movies';

export default function HomePage() {
  const navigate = useNavigate();
  const [selectedGenre, setSelectedGenre] = useState('All');

  const handleMovieClick = (movie: Movie) => {
    navigate(`/watch/${movie.id}`);
  };

  const handlePlay = (movie: Movie) => {
    navigate(`/watch/${movie.id}`);
  };

  const handleMoreInfo = (movie: Movie) => {
    navigate(`/watch/${movie.id}`);
  };

  const handleProfileClick = () => {
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] pb-20">
      <Header transparent onProfileClick={handleProfileClick} />
      
      {/* Hero Section */}
      <HeroSection 
        movie={featuredMovie} 
        onPlay={handlePlay} 
        onMoreInfo={handleMoreInfo} 
      />

      {/* Genre Filter */}
      <div className="px-4 -mt-4 relative z-10">
        <GenreChips 
          genres={genres} 
          selected={selectedGenre} 
          onSelect={setSelectedGenre} 
        />
      </div>

      {/* Content Rows */}
      <div className="mt-6 space-y-2">
        <ContentRow
          title="🔥 Trending Now"
          movies={trendingMovies}
          onMovieClick={handleMovieClick}
          variant="large"
        />

        <ContentRow
          title="🏆 Top 10 This Week"
          movies={top10Movies}
          onMovieClick={handleMovieClick}
          variant="top10"
        />

        <ContentRow
          title="📺 Popular TV Shows"
          movies={tvShows}
          onMovieClick={handleMovieClick}
        />

        <ContentRow
          title="🎬 New Releases"
          movies={[...trendingMovies].reverse()}
          onMovieClick={handleMovieClick}
        />

        <ContentRow
          title="💀 Thriller & Horror"
          movies={[...top10Movies, ...trendingMovies].filter(m => 
            m.genre.includes('Thriller') || m.genre.includes('Horror')
          )}
          onMovieClick={handleMovieClick}
        />
      </div>

      <BottomNav />
    </div>
  );
}
