import { useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import { 
  ArrowLeft, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX,
  Maximize,
  SkipBack,
  SkipForward,
  Download,
  Plus,
  ThumbsUp,
  Share2
} from 'lucide-react';
import { allContent, trendingMovies } from '@/data/movies';
import ContentRow from '@/react-app/components/ContentRow';

export default function WatchPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);

  const movie = allContent.find(m => m.id === id) || allContent[0];

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = (x / rect.width) * 100;
    setProgress(Math.max(0, Math.min(100, percentage)));
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* Video Player */}
      <div className="relative w-full aspect-video bg-black max-h-[70vh]">
        {/* Video placeholder */}
        <img 
          src={movie.backdrop} 
          alt={movie.title}
          className="w-full h-full object-cover"
        />

        {/* Gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40" />

        {/* Top controls */}
        <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between">
          <button 
            onClick={() => navigate(-1)}
            className="w-10 h-10 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center hover:bg-black/70 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 rounded-full bg-black/50 backdrop-blur-sm text-white text-xs font-medium hover:bg-black/70 transition-colors">
              720p
            </button>
          </div>
        </div>

        {/* Center play button */}
        <button 
          onClick={() => setIsPlaying(!isPlaying)}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 hover:bg-white/30 transition-all hover:scale-110"
        >
          {isPlaying ? (
            <Pause className="w-10 h-10 text-white fill-white" />
          ) : (
            <Play className="w-10 h-10 text-white fill-white ml-1" />
          )}
        </button>

        {/* Bottom controls */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          {/* Progress bar */}
          <div 
            className="w-full h-1 bg-white/20 rounded-full mb-4 cursor-pointer group"
            onClick={handleProgressClick}
          >
            <div 
              className="h-full bg-[#E50914] rounded-full relative transition-all"
              style={{ width: `${progress}%` }}
            >
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-[#E50914] rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg" />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button onClick={() => setIsPlaying(!isPlaying)}>
                {isPlaying ? (
                  <Pause className="w-6 h-6 text-white" />
                ) : (
                  <Play className="w-6 h-6 text-white fill-white" />
                )}
              </button>
              <button>
                <SkipBack className="w-5 h-5 text-white/80 hover:text-white transition-colors" />
              </button>
              <button>
                <SkipForward className="w-5 h-5 text-white/80 hover:text-white transition-colors" />
              </button>
              <button onClick={() => setIsMuted(!isMuted)}>
                {isMuted ? (
                  <VolumeX className="w-5 h-5 text-white/80 hover:text-white transition-colors" />
                ) : (
                  <Volume2 className="w-5 h-5 text-white/80 hover:text-white transition-colors" />
                )}
              </button>
              <span className="text-white/70 text-sm">0:00 / {movie.duration}</span>
            </div>
            <button>
              <Maximize className="w-5 h-5 text-white/80 hover:text-white transition-colors" />
            </button>
          </div>
        </div>
      </div>

      {/* Movie Info */}
      <div className="p-4">
        <h1 className="text-2xl font-bold text-white mb-2">{movie.title}</h1>
        
        <div className="flex items-center gap-3 mb-4">
          <span className="text-[#46D369] font-bold text-sm">{movie.match}% Match</span>
          <span className="text-white/60 text-sm">{movie.year}</span>
          <span className="px-1.5 py-0.5 border border-white/30 text-white/60 text-[10px] rounded">
            {movie.rating}
          </span>
          <span className="text-white/60 text-sm">{movie.duration}</span>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-3 mb-6">
          <button className="flex-1 flex items-center justify-center gap-2 py-3 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-colors">
            <Play className="w-5 h-5 fill-black" />
            Play
          </button>
          <button className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
            <Download className="w-5 h-5 text-white" />
          </button>
          <button className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
            <Plus className="w-5 h-5 text-white" />
          </button>
          <button className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
            <ThumbsUp className="w-5 h-5 text-white" />
          </button>
          <button className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
            <Share2 className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Description */}
        <p className="text-white/70 text-sm mb-4">{movie.description}</p>

        {/* Genres */}
        <div className="flex flex-wrap gap-2 mb-8">
          {movie.genre.map((g) => (
            <span 
              key={g}
              className="px-3 py-1 rounded-full bg-white/10 text-white/80 text-xs"
            >
              {g}
            </span>
          ))}
        </div>

        {/* More Like This */}
        <ContentRow
          title="More Like This"
          movies={trendingMovies.filter(m => m.id !== movie.id)}
          onMovieClick={(m) => navigate(`/watch/${m.id}`)}
          showSeeAll={false}
        />
      </div>
    </div>
  );
}
