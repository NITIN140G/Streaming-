import { Download, Trash2, Play } from 'lucide-react';
import { useNavigate } from 'react-router';
import Header from '@/react-app/components/Header';
import BottomNav from '@/react-app/components/BottomNav';
import { trendingMovies } from '@/data/movies';

// Simulated downloads for demo
const downloads = trendingMovies.slice(0, 3);

export default function DownloadsPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#0A0A0A] pt-16 pb-20">
      <Header onProfileClick={() => navigate('/login')} />

      <div className="px-4 py-4">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-white">Downloads</h1>
          <div className="flex items-center gap-2 text-white/50 text-sm">
            <Download className="w-4 h-4" />
            <span>{downloads.length} items</span>
          </div>
        </div>

        {downloads.length > 0 ? (
          <div className="space-y-4">
            {downloads.map((movie) => (
              <div 
                key={movie.id}
                className="flex items-center gap-4 p-3 bg-white/5 rounded-xl border border-white/5 hover:bg-white/10 transition-colors group"
              >
                {/* Thumbnail */}
                <div className="w-20 h-28 rounded-lg overflow-hidden flex-shrink-0 relative">
                  <img 
                    src={movie.poster} 
                    alt={movie.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="w-8 h-8 text-white fill-white" />
                  </div>
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-white font-semibold truncate">{movie.title}</h3>
                  <p className="text-white/50 text-sm mt-1">{movie.duration}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-[#46D369] text-xs font-medium">Downloaded</span>
                    <span className="text-white/30">•</span>
                    <span className="text-white/50 text-xs">1.2 GB</span>
                  </div>
                  {/* Progress bar */}
                  <div className="mt-2 h-1 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-[#E50914] rounded-full" style={{ width: '100%' }} />
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col gap-2">
                  <button 
                    onClick={() => navigate(`/watch/${movie.id}`)}
                    className="w-10 h-10 rounded-full bg-white flex items-center justify-center hover:bg-white/90 transition-colors"
                  >
                    <Play className="w-5 h-5 text-black fill-black ml-0.5" />
                  </button>
                  <button className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-red-500/20 hover:text-red-500 text-white/50 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mb-4">
              <Download className="w-10 h-10 text-white/30" />
            </div>
            <h3 className="text-white font-semibold mb-2">No Downloads</h3>
            <p className="text-white/50 text-sm text-center max-w-xs">
              Movies and shows you download will appear here for offline viewing
            </p>
          </div>
        )}

        {/* Storage info */}
        <div className="mt-8 p-4 bg-white/5 rounded-xl border border-white/5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-white/70 text-sm">Storage Used</span>
            <span className="text-white text-sm font-medium">3.6 GB / 10 GB</span>
          </div>
          <div className="h-2 bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-[#E50914] to-[#FF6B6B] rounded-full" style={{ width: '36%' }} />
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
