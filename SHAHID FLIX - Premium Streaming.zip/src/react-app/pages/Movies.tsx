import { useState } from 'react';
import { useNavigate } from 'react-router';
import Header from '@/react-app/components/Header';
import GenreChips from '@/react-app/components/GenreChips';
import MovieCard from '@/react-app/components/MovieCard';
import BottomNav from '@/react-app/components/BottomNav';
import { trendingMovies, top10Movies, genres, Movie } from '@/data/movies';

const allMovies = [...trendingMovies, ...top10Movies].filter(m => m.type === 'movie');

export default function MoviesPage() {
  const navigate = useNavigate();
  const [selectedGenre, setSelectedGenre] = useState('All');

  const filteredMovies = selectedGenre === 'All' 
    ? allMovies 
    : allMovies.filter(m => m.genre.includes(selectedGenre));

  const handleMovieClick = (movie: Movie) => {
    navigate(`/watch/${movie.id}`);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] pt-16 pb-20">
      <Header onProfileClick={() => navigate('/login')} />

      <div className="px-4 py-4">
        <h1 className="text-2xl font-bold text-white mb-4">Movies</h1>
        
        <GenreChips 
          genres={genres} 
          selected={selectedGenre} 
          onSelect={setSelectedGenre} 
        />

        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3 mt-6">
          {filteredMovies.map((movie) => (
            <div key={movie.id} className="aspect-[2/3]">
              <MovieCard 
                movie={movie} 
                onClick={handleMovieClick}
                size="small"
              />
            </div>
          ))}
        </div>

        {filteredMovies.length === 0 && (
          <div className="text-center py-20">
            <p className="text-white/50">No movies found in this genre</p>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
