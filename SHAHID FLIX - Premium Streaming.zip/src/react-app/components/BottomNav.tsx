import { Home, Film, Tv, Download } from 'lucide-react';
import { Link, useLocation } from 'react-router';

interface NavItem {
  icon: React.ElementType;
  label: string;
  path: string;
}

const navItems: NavItem[] = [
  { icon: Home, label: 'Home', path: '/' },
  { icon: Film, label: 'Movies', path: '/movies' },
  { icon: Tv, label: 'TV Shows', path: '/tv' },
  { icon: Download, label: 'Downloads', path: '/downloads' },
];

export default function BottomNav() {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-xl border-t border-white/5">
      <div className="flex items-center justify-around h-16 max-w-lg mx-auto">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;

          return (
            <Link
              key={item.path}
              to={item.path}
              className="flex flex-col items-center justify-center flex-1 h-full relative group"
            >
              {isActive && (
                <div className="absolute -top-0.5 left-1/2 -translate-x-1/2 w-8 h-1 rounded-full bg-[#E50914] nav-glow" />
              )}
              <Icon
                className={`w-5 h-5 transition-all duration-300 ${
                  isActive 
                    ? 'text-[#E50914] drop-shadow-[0_0_8px_rgba(229,9,20,0.6)]' 
                    : 'text-white/50 group-hover:text-white/80'
                }`}
                strokeWidth={isActive ? 2.5 : 1.5}
              />
              <span
                className={`text-[10px] mt-1 transition-colors duration-300 ${
                  isActive ? 'text-[#E50914]' : 'text-white/50 group-hover:text-white/80'
                }`}
              >
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
