import { Play, Info } from 'lucide-react';
import { Movie } from '@/data/movies';

interface HeroSectionProps {
  movie: Movie;
  onPlay: (movie: Movie) => void;
  onMoreInfo: (movie: Movie) => void;
}

export default function HeroSection({ movie, onPlay, onMoreInfo }: HeroSectionProps) {
  return (
    <section className="relative w-full h-[85vh] min-h-[500px] max-h-[700px]">
      {/* Full-bleed poster image */}
      <div className="absolute inset-0">
        <img
          src={movie.backdrop}
          alt={movie.title}
          className="w-full h-full object-cover"
        />
        {/* Bottom gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/60 to-transparent" />
        {/* Side gradient for text readability */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0A0A0A]/80 via-transparent to-transparent" />
      </div>

      {/* Content overlay */}
      <div className="absolute bottom-0 left-0 right-0 p-6 pb-10">
        {/* Match percentage */}
        <div className="flex items-center gap-2 mb-3">
          <span className="text-[#46D369] font-bold text-sm">
            {movie.match}% Match
          </span>
          <span className="text-white/60 text-sm">{movie.year}</span>
          <span className="px-1.5 py-0.5 border border-white/30 text-white/60 text-[10px] rounded">
            {movie.rating}
          </span>
          <span className="text-white/60 text-sm">{movie.duration}</span>
        </div>

        {/* Title */}
        <h1 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight drop-shadow-2xl">
          {movie.title}
        </h1>

        {/* Genre tags */}
        <div className="flex flex-wrap gap-2 mb-4">
          {movie.genre.map((g) => (
            <span key={g} className="text-white/70 text-xs">
              {g}
              {movie.genre.indexOf(g) < movie.genre.length - 1 && (
                <span className="ml-2 text-white/30">•</span>
              )}
            </span>
          ))}
        </div>

        {/* Description */}
        <p className="text-white/70 text-sm mb-6 max-w-md line-clamp-2">
          {movie.description}
        </p>

        {/* Action buttons */}
        <div className="flex gap-3">
          <button
            onClick={() => onPlay(movie)}
            className="flex items-center gap-2 px-6 py-3 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105"
          >
            <Play className="w-5 h-5 fill-black" />
            Play
          </button>
          <button
            onClick={() => onMoreInfo(movie)}
            className="flex items-center gap-2 px-6 py-3 glass-button text-white font-medium rounded-lg transition-all duration-300 hover:scale-105"
          >
            <Info className="w-5 h-5" />
            More Info
          </button>
        </div>
      </div>
    </section>
  );
}
