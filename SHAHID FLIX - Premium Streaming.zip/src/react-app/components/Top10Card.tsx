import { Play } from 'lucide-react';
import { Movie } from '@/data/movies';

interface Top10CardProps {
  movie: Movie;
  rank: number;
  onClick: (movie: Movie) => void;
}

export default function Top10Card({ movie, rank, onClick }: Top10CardProps) {
  return (
    <button
      onClick={() => onClick(movie)}
      className="relative flex-shrink-0 group w-36 h-48"
    >
      {/* Large rank number behind poster */}
      <span 
        className="absolute -left-2 bottom-0 text-[120px] font-black leading-none select-none z-0"
        style={{
          WebkitTextStroke: '3px rgba(255,255,255,0.3)',
          WebkitTextFillColor: 'transparent',
          textShadow: '0 4px 20px rgba(0,0,0,0.5)'
        }}
      >
        {rank}
      </span>

      {/* Movie poster */}
      <div className="absolute right-0 top-0 w-24 h-36 rounded-xl overflow-hidden shadow-2xl z-10 group-hover:scale-105 transition-transform duration-300">
        <img
          src={movie.poster}
          alt={movie.title}
          className="w-full h-full object-cover"
        />
        
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center">
          <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
            <Play className="w-5 h-5 text-white fill-white ml-0.5" />
          </div>
        </div>
      </div>

      {/* Title below */}
      <p className="absolute bottom-0 right-0 w-24 text-white/80 text-[10px] font-medium truncate text-center">
        {movie.title}
      </p>
    </button>
  );
}
