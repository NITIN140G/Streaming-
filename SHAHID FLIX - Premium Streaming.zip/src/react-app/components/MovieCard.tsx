import { Play } from 'lucide-react';
import { Movie } from '@/data/movies';

interface MovieCardProps {
  movie: Movie;
  onClick: (movie: Movie) => void;
  size?: 'small' | 'medium' | 'large';
}

export default function MovieCard({ movie, onClick, size = 'medium' }: MovieCardProps) {
  const sizeClasses = {
    small: 'w-28 h-40',
    medium: 'w-32 h-48',
    large: 'w-40 h-60'
  };

  return (
    <button
      onClick={() => onClick(movie)}
      className={`relative ${sizeClasses[size]} flex-shrink-0 group overflow-hidden rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 hover:z-10`}
    >
      <img
        src={movie.poster}
        alt={movie.title}
        className="w-full h-full object-cover"
      />
      
      {/* Hover overlay */}
      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center">
        <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
          <Play className="w-6 h-6 text-white fill-white ml-0.5" />
        </div>
      </div>

      {/* Bottom gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      
      {/* Title on hover */}
      <div className="absolute bottom-2 left-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <p className="text-white text-xs font-medium truncate">{movie.title}</p>
      </div>
    </button>
  );
}
