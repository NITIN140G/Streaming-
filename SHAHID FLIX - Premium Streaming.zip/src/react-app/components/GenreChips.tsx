interface GenreChipsProps {
  genres: string[];
  selected: string;
  onSelect: (genre: string) => void;
}

export default function GenreChips({ genres, selected, onSelect }: GenreChipsProps) {
  return (
    <div className="flex gap-2 overflow-x-auto hide-scrollbar py-2 px-1">
      {genres.map((genre) => (
        <button
          key={genre}
          onClick={() => onSelect(genre)}
          className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-300 ${
            selected === genre
              ? 'bg-[#E50914] text-white shadow-lg shadow-[#E50914]/30'
              : 'bg-white/10 text-white/80 hover:bg-white/15'
          }`}
        >
          {genre}
        </button>
      ))}
    </div>
  );
}
