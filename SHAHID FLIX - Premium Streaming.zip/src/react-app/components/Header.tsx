import { Search, Bell, User } from 'lucide-react';
import { Link } from 'react-router';

interface HeaderProps {
  transparent?: boolean;
  onProfileClick?: () => void;
}

export default function Header({ transparent = false, onProfileClick }: HeaderProps) {
  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        transparent 
          ? 'bg-gradient-to-b from-black/70 to-transparent' 
          : 'bg-black/95 backdrop-blur-xl border-b border-white/5'
      }`}
    >
      <div className="flex items-center justify-between h-14 px-4">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <h1 className="text-xl font-black tracking-tight">
            <span className="text-[#E50914]">SHAHID</span>
            <span className="text-white"> FLIX</span>
          </h1>
        </Link>

        {/* Right icons */}
        <div className="flex items-center gap-4">
          <button className="text-white/80 hover:text-white transition-colors">
            <Search className="w-5 h-5" />
          </button>
          <button className="text-white/80 hover:text-white transition-colors relative">
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-[#E50914] rounded-full" />
          </button>
          <button 
            onClick={onProfileClick}
            className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#E50914] to-[#B20710] flex items-center justify-center hover:scale-105 transition-transform"
          >
            <User className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>
    </header>
  );
}
