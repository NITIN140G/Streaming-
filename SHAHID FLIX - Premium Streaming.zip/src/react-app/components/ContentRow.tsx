import { ChevronRight } from 'lucide-react';
import { Movie } from '@/data/movies';
import MovieCard from './MovieCard';
import Top10Card from './Top10Card';

interface ContentRowProps {
  title: string;
  movies: Movie[];
  onMovieClick: (movie: Movie) => void;
  variant?: 'default' | 'large' | 'top10';
  showSeeAll?: boolean;
}

export default function ContentRow({ 
  title, 
  movies, 
  onMovieClick, 
  variant = 'default',
  showSeeAll = true 
}: ContentRowProps) {
  return (
    <section className="mb-8">
      {/* Header */}
      <div className="flex items-center justify-between px-4 mb-3">
        <h2 className="text-lg font-bold text-white">{title}</h2>
        {showSeeAll && (
          <button className="flex items-center gap-1 text-[#E50914] text-sm font-medium hover:underline">
            See All
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Content scroll */}
      <div className="flex gap-3 overflow-x-auto hide-scrollbar px-4">
        {variant === 'top10' ? (
          movies.slice(0, 10).map((movie, index) => (
            <Top10Card
              key={movie.id}
              movie={movie}
              rank={index + 1}
              onClick={onMovieClick}
            />
          ))
        ) : (
          movies.map((movie) => (
            <MovieCard
              key={movie.id}
              movie={movie}
              onClick={onMovieClick}
              size={variant === 'large' ? 'large' : 'medium'}
            />
          ))
        )}
      </div>
    </section>
  );
}
